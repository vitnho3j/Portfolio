function scrollToTop(){
    var div = document.getElementById('begin');
    div.style.scrollBehavior = "smooth"
    div.scrollTop = 0
}
